<?php
require_once 'includes/front_config.php';

$page_title = "Nuestros Cines";

// Obtener cines activos
try {
    $cines = $db->query("SELECT * FROM tbl_locales WHERE estado = '1' ORDER BY orden ASC, nombre ASC")->fetchAll();
} catch (PDOException $e) {
    $cines = [];
}

include 'includes/header_front.php';
include 'includes/slider_front.php';
?>

<div class="container">
    <h2 class="section-title">Elige tu Cine Favorito</h2>

    <div class="grid">
        <?php foreach ($cines as $cine): ?>
            <div class="card">
                <?php
                $img_path = !empty($cine['img']) ? UPLOADS_URL . 'cines/' . $cine['img'] : 'https://via.placeholder.com/600x350?text=Cinerama';
                ?>
                <img src="<?php echo $img_path; ?>" alt="<?php echo htmlspecialchars($cine['nombre']); ?>" class="card-img" style="height: auto; object-fit: contain; max-height: 300px; width: 100%;">

                <div class="card-info">
                    <h3 class="card-title"><?php echo htmlspecialchars($cine['nombre']); ?></h3>
                    <p class="card-text">
                        <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($cine['direccion']); ?>
                    </p>
                    <a href="cartelera_cine.php?id=<?php echo $cine['id']; ?>" class="btn" style="display: block; width: 100%; box-sizing: border-box;">
                        Ver Cartelera
                    </a>
                </div>
            </div>
        <?php endforeach; ?>

        <?php if (empty($cines)): ?>
            <p style="text-align: center; color: #666; width: 100%;">No hay cines disponibles en este momento.</p>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer_front.php'; ?>
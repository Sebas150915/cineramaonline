    <footer style="background: #0a0a0a; padding: 40px; text-align: center; margin-top: 60px; border-top: 1px solid #222;">
        <p style="color: #666;">&copy; <?php echo date('Y'); ?> Cinerama. Todos los derechos reservados.</p>
    </footer>
    </body>

    </html>
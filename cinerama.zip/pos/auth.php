<?php
session_start();
require_once '../panel/config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'] ?? '';
    $password = $_POST['password'] ?? '';

    try {
        $stmt = $db->prepare("SELECT * FROM tbl_usuarios WHERE usuario = ? AND estado = '1'");
        $stmt->execute([$usuario]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['pos_user_id'] = $user['id'];
            $_SESSION['pos_user_nombre'] = $user['nombre'];
            $_SESSION['pos_user_usuario'] = $user['usuario'];
            $_SESSION['pos_user_rol'] = $user['rol'];
            $_SESSION['pos_id_local'] = $user['id_local'];

            header("Location: dashboard.php");
            exit;
        } else {
            header("Location: index.php?error=1");
            exit;
        }
    } catch (PDOException $e) {
        die("Error de base de datos");
    }
} else {
    header("Location: index.php");
    exit;
}

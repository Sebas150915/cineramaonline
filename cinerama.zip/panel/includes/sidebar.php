<!-- Sidebar -->
<nav class="admin-sidebar">
    <!-- Gestión de Contenido -->
    <div class="sidebar-section">
        <div class="sidebar-title">Gestión de Contenido</div>
        <ul class="sidebar-menu">
            <li class="menu-item <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'active' : ''; ?>">
                <a href="<?php echo BASE_URL; ?>index.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/peliculas/">
                    <i class="fas fa-video"></i>
                    <span>Películas</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/cartelera/">
                    <i class="fas fa-calendar-alt"></i>
                    <span>Cartelera</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/funciones/">
                    <i class="fas fa-film"></i>
                    <span>Funciones</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/horarios/">
                    <i class="fas fa-clock"></i>
                    <span>Horarios</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Configuración -->
    <div class="sidebar-section">
        <div class="sidebar-title">Configuración</div>
        <ul class="sidebar-menu">
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/censuras/">
                    <i class="fas fa-ban"></i>
                    <span>Censuras</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/generos/">
                    <i class="fas fa-theater-masks"></i>
                    <span>Géneros</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/distribuidoras/">
                    <i class="fas fa-building"></i>
                    <span>Distribuidoras</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/cines/">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>Locales</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/tarifas/">
                    <i class="fas fa-ticket-alt"></i>
                    <span>Tarifas</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/slider/">
                    <i class="fas fa-images"></i>
                    <span>Slider Home</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Comunicación -->
    <div class="sidebar-section">
        <div class="sidebar-title">Comunicación</div>
        <ul class="sidebar-menu">
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/contactos/">
                    <i class="fas fa-envelope"></i>
                    <span>Mensajes</span>
                    <span class="notification-badge">8</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/promociones/">
                    <i class="fas fa-tag"></i>
                    <span>Promociones</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/noticias/">
                    <i class="fas fa-newspaper"></i>
                    <span>Noticias</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Reportes -->
    <div class="sidebar-section">
        <div class="sidebar-title">Reportes</div>
        <ul class="sidebar-menu">
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/ventas/">
                    <i class="fas fa-chart-bar"></i>
                    <span>Ventas</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/asistencia/">
                    <i class="fas fa-users"></i>
                    <span>Asistencia</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?php echo BASE_URL; ?>modules/inventario/">
                    <i class="fas fa-boxes"></i>
                    <span>Inventario</span>
                </a>
            </li>
        </ul>
    </div>
</nav>
<?php

/**
 * Configuración General - Cinerama Panel
 */

// Iniciar sesión
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Zona horaria
date_default_timezone_set('America/Lima');

// Configuración de errores (cambiar en producción)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Rutas base
define('BASE_PATH', dirname(__DIR__));
define('BASE_URL', 'http://localhost/cinerama/panel/');
define('ASSETS_URL', BASE_URL . 'assets/');
define('UPLOADS_URL', 'http://localhost/cinerama/uploads/');

// Configuración de la aplicación
define('APP_NAME', 'Cinerama Admin');
define('APP_VERSION', '1.0.0');

// Incluir archivos necesarios
require_once BASE_PATH . '/config/database.php';
require_once BASE_PATH . '/helpers/functions.php';

// Crear instancia de base de datos
$database = new Database();
$db = $database->getConnection();

// Verificar conexión
if (!$db) {
    die("Error: No se pudo conectar a la base de datos");
}

/**
 * JavaScript Principal - Cinerama Panel
 */

$(document).ready(function () {

    // Inicializar DataTables con configuración en español
    if ($.fn.DataTable) {
        $('.datatable').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/es-ES.json'
            },
            pageLength: 25,
            order: [[0, 'desc']],
            responsive: true
        });
    }

    // Confirmación de eliminación
    $('.btn-delete').on('click', function (e) {
        e.preventDefault();
        const url = $(this).attr('href');
        const itemName = $(this).data('name') || 'este elemento';

        Swal.fire({
            title: '¿Estás seguro?',
            text: `¿Deseas eliminar ${itemName}? Esta acción no se puede deshacer.`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#e62429',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = url;
            }
        });
    });

    // Activar/Desactivar elementos
    $('.btn-toggle-status').on('click', function (e) {
        e.preventDefault();
        const url = $(this).attr('href');

        $.ajax({
            url: url,
            type: 'GET',
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Éxito',
                        text: response.message,
                        confirmButtonColor: '#e62429'
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message,
                        confirmButtonColor: '#e62429'
                    });
                }
            },
            error: function () {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Ocurrió un error al procesar la solicitud',
                    confirmButtonColor: '#e62429'
                });
            }
        });
    });

    // Validación de formularios
    $('form').on('submit', function (e) {
        const requiredFields = $(this).find('[required]');
        let isValid = true;

        requiredFields.each(function () {
            if (!$(this).val()) {
                isValid = false;
                $(this).addClass('is-invalid');
            } else {
                $(this).removeClass('is-invalid');
            }
        });

        if (!isValid) {
            e.preventDefault();
            Swal.fire({
                icon: 'error',
                title: 'Campos requeridos',
                text: 'Por favor completa todos los campos obligatorios',
                confirmButtonColor: '#e62429'
            });
        }
    });

    // Preview de imágenes
    $('input[type="file"]').on('change', function (e) {
        const file = e.target.files[0];
        const preview = $(this).data('preview');

        if (file && preview) {
            const reader = new FileReader();
            reader.onload = function (e) {
                $(preview).attr('src', e.target.result).show();
            };
            reader.readAsDataURL(file);
        }
    });

    // Marcar menú activo
    const currentPage = window.location.pathname;
    $('.menu-item a').each(function () {
        if ($(this).attr('href') === currentPage) {
            $(this).parent().addClass('active');
        }
    });

});
